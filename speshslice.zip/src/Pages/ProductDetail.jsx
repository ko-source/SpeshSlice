import React from 'react';
import { FaStar, FaShoppingCart, FaMinus, FaPlus } from 'react-icons/fa';
import Button from '../Components/Button';
import cake from '../assets/images/cake.png'
export default function CakeDetail() {
    return (
        <div className="w-full">
            <section className="relative">
                <div className="container mx-auto px-4">
                    <div className="mb-12 flex flex-wrap -mx-4 justify-end">
                        
                    </div>
                    <div className="flex flex-wrap -mx-4">
                        <div className="mx-auto px-4 relative w-full lg:w-6/12 w-full md:w-full">
                            <div className="relative">
                                <div className="relative w-full overflow-hidden">
                                    <div className="w-full p-12 transform duration-500 transition-all ease-in-out mx-auto block">
                                        <img alt="..." src={cake} className="w-full h-auto mx-auto" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mr-auto px-4 relative w-full lg:w-6/12 w-full md:w-full">
                            <h2 className="text-3xl font-bold leading-tight mt-0 mb-0">Delicious Chocolate Cake</h2>
                            <div className="pt-2 ">
                                <div className="text-orange-500 flex justify-center"><FaStar /><FaStar /><FaStar /><FaStar /><FaStar /></div>
                            </div>
                            <h2 className="text-3xl font-normal mt-2 mb-2">$29.99</h2>
                            <p className="text-blueGray-500">Indulge in the rich, moist, and chocolatey goodness of our classic chocolate cake. Made with premium ingredients and topped with chocolate ganache, it's perfect for any occasion.</p>
                           
                            <div className="mb-6 flex flex-wrap justify-center ">
                                <div className="px-4 relative w-full lg:w-5/12">
                                    <label className="inline-block mb-2">Quantity</label>
                                    <div className="relative inline-flex flex-row w-full items-stretch">
                                        <div className="mr-2">
                                            <button className="inline-block outline-none focus:outline-none align-middle transition-all duration-150 ease-in-out uppercase border border-solid font-bold last:mr-0 mr-2  text-white bg-pink-500 border-pink-500 active:bg-pink-600 active:border-pink-600 text-sm px-6 py-2 shadow hover:shadow-lg rounded-md">
                                                <FaMinus />
                                            </button>
                                        </div>
                                        <div className="mr-2">
                                            <div className="mb-3 pt-0">
                                                <input type="text" className="border-blueGray-300 px-3 py-2 text-sm  w-full placeholder-blueGray-200 text-blueGray-700 relative bg-white rounded-md outline-none focus:ring focus:ring-lightBlue-500 focus:ring-1 focus:border-lightBlue-500 border border-solid transition duration-200 " value="1" />
                                            </div>
                                        </div>
                                        <div>
                                            <button className="inline-block outline-none focus:outline-none align-middle transition-all duration-150 ease-in-out uppercase border border-solid font-bold last:mr-0 mr-2  text-white  bg-pink-500 border-pink-500 active:bg-pink-600 active:border-pink-600text-sm px-6 py-2 shadow hover:shadow-lg rounded-md">
                                                <FaPlus />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="px-4 relative w-full lg:w-6/12">
                                    <label className="inline-block mb-2">Size</label>
                                   
                                        <div className="mb-3 pt-0">
                                            <input placeholder="Size in pound" type="text" className="border-blueGray-300 px-3 py-2 text-sm  w-full placeholder-blueGray-200 text-blueGray-700 relative bg-white rounded-md outline-none focus:ring focus:ring-lightBlue-500 focus:ring-1 focus:border-lightBlue-500 border border-solid transition duration-200 " value="" />
                                        </div>
                                    
                                </div>
                            </div>
                            <div className="add-cart mt-5">
                                <Button className="w-[70%]">
                                    <a className="add" href="shop-cart.html">
                                        Add to Cart
                                    </a>
                                    <FaShoppingCart />
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
